
Using the tool LTSA-PCA

1. Open the folder LTSA-PCA
2. Click on the jar file LTSA-PCA.jar
3. On the tool menu go to FIle>Open and select a PCA file from the folder Desktop>>LTSA-PCA>examples>examples. Select any .pca file from the folder. I used 'e-shopping.pca'
4. The code would be loaded into LTSA now. Go to Build>Compose.
5. An output tab displaying the number of states would be visible now.
6. Now visit the Draw tab. On the left side of the pane there will be different options. Select one of those and the state diagram will be visible on the right side of the pane. In my cas(e-shopping.pca, two options-E-Commerce' and 'E-Commerce two clients'. Select any one of those and view the state diagram on the right side of the window pane.
7. end of demo.

