#! /bin/bash
/usr/bin/gsettings set org.gnome.desktop.screensaver lock-enabled false
